import express from 'express';
import puppeteer from 'puppeteer';

const FLAG = process.env.FLAG || 'SK-CERT{fake_flag_for_handout}';
const CHALLENGE_URL = process.env.CHALLENGE_URL || 'http://127.0.0.1:5173';
const BOT_HOST = process.env.BOT_HOST || '0.0.0.0';
const BOT_PORT = Number(process.env.BOT_PORT || 3000);
const MAX_CONCURRENT = Number(process.env.MAX_CONCURRENT || 10);

let activeVisits = 0;

function isValidVisitUrl(url) {
  try {
    const parsed = new URL(url);
    return parsed.protocol === 'http:' || parsed.protocol === 'https:';
  } catch {
    return false;
  }
}

async function waitKernelReady(page, timeoutMs = 120000) {
  await page.waitForFunction(
    () => {
      const label = document.querySelector('.kernel-label')?.textContent || '';
      return /ready|idle/i.test(label);
    },
    { timeout: timeoutMs }
  );
}

async function waitCellDone(page, cellIndex, timeoutMs = 120000) {
  await page.waitForFunction(
    (idx) => {
      const cell = document.querySelectorAll('.cell')[idx];
      return !!cell && !cell.classList.contains('running');
    },
    { timeout: timeoutMs },
    cellIndex
  );
}

async function setCellSource(page, cellIndex, source) {
  const editor = page.locator('.cell').nth(cellIndex).locator('.cell-editor');
  await editor.click();
  await editor.fill(source);
}

async function runCell(page, cellIndex) {
  const runButton = page.locator('.cell').nth(cellIndex).locator('.run-btn');
  await runButton.click();
  await waitCellDone(page, cellIndex);
}

function randomSuffix(length = 8) {
  const alphabet = 'abcdefghijklmnopqrstuvwxyz0123456789';
  return Array.from({ length }, () => alphabet[Math.floor(Math.random() * alphabet.length)]).join('');
}

async function registerUser(page, username, password) {
  const base = CHALLENGE_URL.replace(/\/$/, '');
  const authUrl = `${base}/auth/?mode=register&return=${encodeURIComponent(base)}`;

  await page.goto(authUrl, { waitUntil: 'domcontentloaded', timeout: 20000 });
  await page.locator('input[autocomplete="username"]').fill(username);
  await page.locator('input[type="password"]').fill(password);
  await page.locator('#auth-page-submit').click();
  await page.waitForURL(`${base}*`, { timeout: 30000 });
}

async function createFlagMarkdown(page, flagValue) {
  await waitKernelReady(page);
  await page.locator('.sidebar-header button', { hasText: '+ New' }).click();
  await page.locator('.cell').nth(0).locator('select.cell-type').selectOption('markdown');
  await setCellSource(page, 0, `# note\n\n${flagValue}\n`);
  await runCell(page, 0);
}

async function performVisit(url) {
  const browser = await puppeteer.launch({
    headless: true,
    executablePath: process.env.PUPPETEER_EXECUTABLE_PATH || undefined,
    args: [
      '--no-sandbox',
      '--disable-setuid-sandbox',
      '--disable-dev-shm-usage',
      '--disable-gpu'
    ]
  });

  try {
    const firstPage = await browser.newPage();

    // check protocol
    const parsedUrl = new URL(url);
    if (parsedUrl.protocol !== 'http:' && parsedUrl.protocol !== 'https:') {
      throw new Error('Invalid URL protocol');
    }

    await firstPage.goto(url, { timeout: 10000, waitUntil: 'networkidle2' });
    await firstPage.waitForTimeout(3000);
    await firstPage.close();

    const secondPage = await browser.newPage();

    const username = `ctf_${randomSuffix()}`;
    const password = 'ctfpass123';
    await registerUser(secondPage, username, password);
    await createFlagMarkdown(secondPage, FLAG);
    await secondPage.waitForTimeout(1000);
    await secondPage.close();
  } finally {
    await browser.close();
  }
}

const app = express();
app.use(express.json());

app.get('/health', (req, res) => {
  res.sendStatus(200);
});

app.post('/visit', async (req, res) => {
  const { url } = req.body ?? {};

  if (!url || typeof url !== 'string') {
    return res.status(400).json({ error: 'missing url' });
  }

  if (!isValidVisitUrl(url)) {
    return res.status(400).json({ error: 'url must be http or https' });
  }

  if (activeVisits >= MAX_CONCURRENT) {
    return res.status(429).json({ error: 'too many concurrent visits' });
  }

  activeVisits += 1;

  try {
    await performVisit(url);
    return res.json({ status: 'visited' });
  } catch (err) {
    console.error('visit error:', err?.message || err);
    return res.status(500).json({ error: 'visit failed' });
  } finally {
    activeVisits -= 1;
  }
});

app.listen(BOT_PORT, BOT_HOST, () => {
  console.log(`bot listening on ${BOT_HOST}:${BOT_PORT}`);
});