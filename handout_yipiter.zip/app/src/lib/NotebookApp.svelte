<script>
  import { onMount, onDestroy } from 'svelte';

  export let allowUrlImport = false;

  const USERS_KEY = 'yipiii.users.v1';
  const SESSION_KEY = 'yipiii.session.v1';

  let worker;
  let workerReady = false;
  let kernelBusy = false;
  let kernelStatus = { status: 'loading', message: 'Starting yipiii kernel…' };

  let cells = [];
  let cellIdCounter = 0;
  let execQueue = [];

  let currentUser = null;
  let currentNotebookName = 'Untitled';
  let currentNotebookSaved = false;

  let showSaveModal = false;
  let saveName = 'Untitled';
  let saveError = '';

  let fileInput;

  const AUTO_RESIZE_SCRIPT = `<script>(function(){function report(){var h=document.documentElement.scrollHeight;parent.postMessage({type:'yipiii-resize',height:h},'*')}document.addEventListener('DOMContentLoaded',report);window.addEventListener('load',report);if(typeof ResizeObserver!=='undefined'){window.addEventListener('DOMContentLoaded',function(){if(document.body)new ResizeObserver(report).observe(document.body)})}}());<\/script>`;

  function loadUsers() {
    try { return JSON.parse(localStorage.getItem(USERS_KEY) || '{}'); } catch { return {}; }
  }

  function saveUsers(users) {
    localStorage.setItem(USERS_KEY, JSON.stringify(users));
  }

  function getCurrentUserNotebooks() {
    if (!currentUser) return {};
    const users = loadUsers();
    return users[currentUser]?.notebooks || {};
  }

  function updateNotebookHash() {
    const encoded = encodeURIComponent(currentNotebookName || 'Untitled');
    window.location.hash = `nb=${encoded}`;
  }

  function readNotebookNameFromHash() {
    const raw = window.location.hash.replace(/^#/, '');
    if (!raw) return '';
    const params = new URLSearchParams(raw);
    return params.get('nb') || '';
  }

  function setCurrentNotebook(name, { saved = false, syncHash = true } = {}) {
    currentNotebookName = (name && String(name).trim()) || 'Untitled';
    currentNotebookSaved = !!saved;
    if (syncHash) updateNotebookHash();
  }

  function markNotebookDirty() {
    if (!currentNotebookSaved) return;
    currentNotebookSaved = false;
  }

  function notebookChip() {
    return currentNotebookSaved ? currentNotebookName : `${currentNotebookName} (unsaved)`;
  }

  function makeCell(type = 'code', source = '') {
    return {
      id: `cell-${++cellIdCounter}`,
      type,
      source,
      execCount: null,
      running: false,
      error: false,
      outputs: []
    };
  }

  function seedDefaultCells() {
    setCurrentNotebook('Untitled', { saved: false });
    cells = [
      makeCell('code', `# yipiii – Welcome!\n# Shift+Enter to run a cell. Everything runs in WebAssembly Python (Pyodide).\n\nprint("Hello from yipiii! 🎉")\n`),
      makeCell('markdown', `# Markdown example\n# Markdown cells are rendered in a sandboxed blob iframe.\n\nYou can switch any cell to markdown from the cell toolbar.\n`),
      makeCell('code', `# Matplotlib example\nimport matplotlib.pyplot as plt\nimport numpy as np\n\nx = np.linspace(0, 2 * np.pi, 400)\nfig, ax = plt.subplots(figsize=(6, 3))\nax.plot(x, np.sin(x), label='sin(x)', linewidth=2)\nax.plot(x, np.cos(x), label='cos(x)', linewidth=2)\nax.legend(); ax.grid(True, alpha=0.3)\nax.set_title('Matplotlib in the browser')\nplt.show()\n`)
    ];
  }

  function findCell(id) { return cells.find((c) => c.id === id); }

  function appendCell(type = 'code', source = '') {
    cells = [...cells, makeCell(type, source)];
  }

  function deleteCell(id) {
    if (cells.length <= 1) {
      cells = [{ ...cells[0], source: '', outputs: [], execCount: null, error: false, running: false }];
      markNotebookDirty();
      return;
    }
    cells = cells.filter((c) => c.id !== id);
    markNotebookDirty();
  }

  function moveCellUp(id) {
    const i = cells.findIndex((c) => c.id === id);
    if (i <= 0) return;
    const next = [...cells];
    const temp = next[i - 1];
    next[i - 1] = next[i];
    next[i] = temp;
    cells = next;
    markNotebookDirty();
  }

  function moveCellDown(id) {
    const i = cells.findIndex((c) => c.id === id);
    if (i < 0 || i >= cells.length - 1) return;
    const next = [...cells];
    const temp = next[i + 1];
    next[i + 1] = next[i];
    next[i] = temp;
    cells = next;
    markNotebookDirty();
  }

  function clearOutput(cellId) {
    const cell = findCell(cellId);
    if (!cell) return;
    cell.outputs = [];
    cells = [...cells];
  }

  function stripAnsi(str) {
    return String(str || '').replace(/\x1b\[[0-9;]*[mGKHF]/g, '');
  }

  function wrapHtml(html) {
    if (/<!doctype/i.test(html)) {
      return html.includes(AUTO_RESIZE_SCRIPT) ? html : html.replace('</head>', AUTO_RESIZE_SCRIPT + '</head>');
    }
    return '<!DOCTYPE html><html><head><meta charset="utf-8"><style>html,body{margin:0;padding:8px;font-family:system-ui,sans-serif;background:#fff;color:#111;box-sizing:border-box;}</style>' + AUTO_RESIZE_SCRIPT + '</head><body>' + html + '</body></html>';
  }

  function wrapSvg(svg) {
    return '<!DOCTYPE html><html><head><meta charset="utf-8"><style>html,body{margin:0;padding:0;background:transparent;}svg{max-width:100%;height:auto;display:block;}</style>' + AUTO_RESIZE_SCRIPT + '</head><body>' + svg + '</body></html>';
  }

  function renderMarkdown(md) {
    return '<p>' + String(md || '')
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
      .replace(/^#{6}\s(.+)$/gm, '<h6>$1</h6>')
      .replace(/^#{5}\s(.+)$/gm, '<h5>$1</h5>')
      .replace(/^#{4}\s(.+)$/gm, '<h4>$1</h4>')
      .replace(/^#{3}\s(.+)$/gm, '<h3>$1</h3>')
      .replace(/^#{2}\s(.+)$/gm, '<h2>$1</h2>')
      .replace(/^#{1}\s(.+)$/gm, '<h1>$1</h1>')
      .replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>')
      .replace(/\*(.+?)\*/g, '<em>$1</em>')
      .replace(/\u0060([^\u0060]+)\u0060/g, '<code>$1</code>')
      .replace(/\[(.+?)\]\((.+?)\)/g, '<a href="$2" target="_blank" rel="noreferrer">$1</a>')
      .replace(/\n\n/g, '</p><p>')
      .replace(/\n/g, '<br>') + '</p>';
  }

  function makeBlobFrame(doc) {
    const blob = new Blob([doc], { type: 'text/html' });
    return URL.createObjectURL(blob);
  }

  function appendStreamOutput(cell, name, text) {
    const cls = name === 'stderr' ? 'stderr' : 'stdout';
    const last = cell.outputs[cell.outputs.length - 1];
    if (last && last.kind === 'text' && last.stream === cls) {
      last.text += stripAnsi(text);
      return;
    }
    cell.outputs.push({ kind: 'text', stream: cls, text: stripAnsi(text) });
  }

  function appendDisplayData(cell, bundle, outputType = 'display_data') {
    if (bundle['image/png']) {
      cell.outputs.push({
        kind: 'image',
        src: `data:image/png;base64,${bundle['image/png']}`,
        outputType,
        data: { 'image/png': bundle['image/png'] }
      });
      return;
    }
    if (bundle['image/svg+xml']) {
      cell.outputs.push({
        kind: 'iframe',
        src: makeBlobFrame(wrapSvg(bundle['image/svg+xml'])),
        height: 96,
        outputType,
        data: { 'image/svg+xml': bundle['image/svg+xml'] }
      });
      return;
    }
    if (bundle['text/html']) {
      cell.outputs.push({
        kind: 'iframe',
        src: makeBlobFrame(wrapHtml(bundle['text/html'])),
        height: 120,
        outputType,
        data: { 'text/html': bundle['text/html'] }
      });
      return;
    }
    if (bundle['text/markdown']) {
      cell.outputs.push({
        kind: 'iframe',
        src: makeBlobFrame(wrapHtml(renderMarkdown(bundle['text/markdown']))),
        height: 120,
        outputType,
        data: { 'text/markdown': bundle['text/markdown'] }
      });
      return;
    }
    if (bundle['text/plain']) {
      cell.outputs.push({
        kind: 'displayText',
        text: stripAnsi(bundle['text/plain']),
        outputType,
        data: { 'text/plain': stripAnsi(bundle['text/plain']) }
      });
      return;
    }
    const fallbackText = JSON.stringify(bundle, null, 2);
    cell.outputs.push({
      kind: 'displayText',
      text: fallbackText,
      outputType,
      data: { 'text/plain': fallbackText }
    });
  }

  function appendErrorOutput(cell, ename, evalue, traceback = []) {
    const content = traceback.length ? stripAnsi(traceback.join('\n')) : `${ename}: ${evalue}`;
    cell.outputs.push({ kind: 'error', text: content });
  }

  function executeMarkdown(cell) {
    cell.execCount = null;
    cell.running = false;
    cell.error = false;
    cell.outputs = [{ kind: 'iframe', src: makeBlobFrame(wrapHtml(renderMarkdown(cell.source))), height: 120 }];
    cells = [...cells];
  }

  function runCell(cellId) {
    const cell = findCell(cellId);
    if (!cell) return;
    if (cell.type === 'markdown') {
      executeMarkdown(cell);
      return;
    }
    if (!workerReady || kernelBusy) {
      if (!execQueue.includes(cellId)) execQueue = [...execQueue, cellId];
      return;
    }
    startExecution(cellId);
  }

  function runAll() {
    for (const cell of cells) {
      if (cell.type === 'markdown') executeMarkdown(cell);
      else if (!execQueue.includes(cell.id)) execQueue = [...execQueue, cell.id];
    }
    drainQueue();
  }

  function drainQueue() {
    if (!workerReady || kernelBusy || execQueue.length === 0) return;
    startExecution(execQueue[0]);
  }

  function startExecution(cellId) {
    const cell = findCell(cellId);
    if (!cell) {
      execQueue = execQueue.filter((id) => id !== cellId);
      return;
    }
    kernelBusy = true;
    kernelStatus = { status: 'busy', message: 'Kernel busy…' };
    cell.outputs = [];
    cell.error = false;
    cells = [...cells];
    worker.postMessage({ type: 'execute', cellId, code: cell.source });
  }

  function finishCell(cellId, isError = false) {
    const cell = findCell(cellId);
    if (cell) {
      cell.running = false;
      if (isError) cell.error = true;
    }
    kernelBusy = false;
    if (workerReady) kernelStatus = { status: 'ready', message: 'Kernel idle' };
    execQueue = execQueue.filter((id) => id !== cellId);
    cells = [...cells];
    drainQueue();
  }

  function handleWorkerMessage(data) {
    if (data.type === 'status') {
      kernelStatus = { status: data.status, message: data.message };
      if (data.status === 'ready') {
        workerReady = true;
        kernelBusy = false;
        drainQueue();
      }
      return;
    }

    if (data.type === 'execute_input') {
      const cell = findCell(data.cellId);
      if (!cell) return;
      cell.running = true;
      cell.error = false;
      cell.execCount = data.execCount;
      cells = [...cells];
      return;
    }

    if (data.type === 'kernel_msg') {
      const payload = data.payload || {};
      const cell = findCell(payload.cellId || execQueue[0]);
      if (!cell) return;
      if (payload.type === 'stream') appendStreamOutput(cell, payload.name, payload.text);
      if (payload.type === 'display_data') appendDisplayData(cell, payload.data || {}, 'display_data');
      cells = [...cells];
      return;
    }

    if (data.type === 'execute_result') {
      finishCell(data.cellId, false);
      return;
    }

    if (data.type === 'execute_error') {
      const cell = findCell(data.cellId);
      if (cell) appendErrorOutput(cell, data.ename, data.evalue, data.traceback || []);
      finishCell(data.cellId, true);
    }
  }

  function initWorker() {
    if (worker) worker.terminate();
    worker = new Worker('/pyodide-worker.js');
    worker.onmessage = ({ data }) => handleWorkerMessage(data);
    worker.postMessage({ type: 'init' });
  }

  function restartKernel() {
    workerReady = false;
    kernelBusy = false;
    execQueue = [];
    kernelStatus = { status: 'loading', message: 'Restarting kernel…' };
    for (const c of cells) {
      c.running = false;
      c.error = false;
      c.execCount = null;
    }
    cells = [...cells];
    initWorker();
  }

  function normalizeTextChunk(value) {
    if (Array.isArray(value)) return value.join('');
    if (value === null || value === undefined) return '';
    return String(value);
  }

  function normalizeMimeBundle(data) {
    const bundle = {};
    if (!data || typeof data !== 'object') return bundle;
    for (const [mime, value] of Object.entries(data)) bundle[mime] = normalizeTextChunk(value);
    return bundle;
  }

  function normalizeOutput(output) {
    if (!output || typeof output !== 'object') return null;
    if (output.output_type === 'stream') return { output_type: 'stream', name: output.name === 'stderr' ? 'stderr' : 'stdout', text: normalizeTextChunk(output.text) };
    if (output.output_type === 'display_data' || output.output_type === 'execute_result') return { output_type: output.output_type, data: normalizeMimeBundle(output.data) };
    if (output.output_type === 'error') return { output_type: 'error', ename: normalizeTextChunk(output.ename || 'Error'), evalue: normalizeTextChunk(output.evalue || ''), traceback: Array.isArray(output.traceback) ? output.traceback.map(normalizeTextChunk) : [] };
    return null;
  }

  function normalizeNotebook(notebookJson) {
    const rawCells = Array.isArray(notebookJson?.cells) ? notebookJson.cells : [];
    const normalized = rawCells.filter((c) => c && (c.cell_type === 'code' || c.cell_type === 'markdown')).map((c) => {
      const source = Array.isArray(c.source) ? c.source.join('') : String(c.source ?? '');
      if (c.cell_type === 'markdown') return { type: 'markdown', source };
      const outputs = Array.isArray(c.outputs) ? c.outputs.map(normalizeOutput).filter(Boolean) : [];
      return { type: 'code', source, executionCount: Number.isInteger(c.execution_count) ? c.execution_count : null, outputs };
    });
    return normalized.length ? normalized : [{ type: 'code', source: '' }];
  }

  function loadNotebookCells(cellData) {
    cells = cellData.map((item) => {
      const c = makeCell(item.type, item.source);
      if (item.type === 'code' && Number.isInteger(item.executionCount)) c.execCount = item.executionCount;
      if (item.type === 'code' && Array.isArray(item.outputs)) {
        for (const output of item.outputs) {
          if (output.output_type === 'stream') appendStreamOutput(c, output.name, output.text);
          if (output.output_type === 'display_data' || output.output_type === 'execute_result') appendDisplayData(c, output.data || {}, output.output_type);
          if (output.output_type === 'error') appendErrorOutput(c, output.ename || 'Error', output.evalue || '', output.traceback || []);
        }
      }
      if (item.type === 'markdown') c.execCount = null;
      return c;
    });
  }

  async function importNotebookFromUrl(url) {
    const response = await fetch(url);
    if (!response.ok) throw new Error(`Unable to fetch notebook: HTTP ${response.status}`);
    const notebookJson = await response.json();
    setCurrentNotebook(notebookJson?.metadata?.name || 'Imported from URL', { saved: false });
    loadNotebookCells(normalizeNotebook(notebookJson));
  }

  async function importNotebookFromFile(file) {
    const text = await file.text();
    const notebookJson = JSON.parse(text);
    setCurrentNotebook(file.name.replace(/\.ipynb$/i, '') || 'Imported notebook', { saved: false });
    loadNotebookCells(normalizeNotebook(notebookJson));
  }

  function serializeCodeOutputs(outputs = []) {
    return outputs.flatMap((out) => {
      if (out.kind === 'text' && (out.stream === 'stdout' || out.stream === 'stderr')) {
        return [{
          output_type: 'stream',
          name: out.stream,
          text: out.text ?? ''
        }];
      }

      if (out.kind === 'error') {
        const text = String(out.text || 'Error');
        return [{
          output_type: 'error',
          ename: 'Error',
          evalue: text,
          traceback: text.split('\n')
        }];
      }

      if (out.data && typeof out.data === 'object') {
        return [{
          output_type: out.outputType === 'execute_result' ? 'execute_result' : 'display_data',
          data: out.data,
          metadata: {}
        }];
      }

      return [];
    });
  }

  function getNotebookData() {
    return {
      nbformat: 4,
      nbformat_minor: 5,
      metadata: { yipiii: true, name: currentNotebookName },
      cells: cells.map((cell) => ({
        cell_type: cell.type === 'markdown' ? 'markdown' : 'code',
        metadata: {},
        source: cell.source.split('\n').map((line, i, arr) => (i === arr.length - 1 ? line : `${line}\n`)),
        execution_count: cell.type === 'code' ? (Number.isInteger(cell.execCount) ? cell.execCount : null) : undefined,
        outputs: cell.type === 'code' ? serializeCodeOutputs(cell.outputs) : undefined
      }))
    };
  }

  function saveNotebook() {
    if (!currentUser) {
      openAuth('login');
      return;
    }
    const requestedName = String(saveName || '').trim();
    if (!requestedName) {
      saveError = 'Notebook name is required.';
      return;
    }

    setCurrentNotebook(requestedName, { saved: true });
    const users = loadUsers();
    users[currentUser] ||= { password: '', notebooks: {} };
    users[currentUser].notebooks[currentNotebookName] = { savedAt: new Date().toISOString(), data: getNotebookData() };
    saveUsers(users);
    showSaveModal = false;
  }

  function openNotebookByName(name) {
    const notebooks = getCurrentUserNotebooks();
    const data = notebooks[name]?.data;
    if (!data) return;
    setCurrentNotebook(name, { saved: true });
    loadNotebookCells(normalizeNotebook(data));
  }

  function openAuth(mode = 'login') {
    const page = new URL('/auth/', window.location.origin);
    page.searchParams.set('mode', mode === 'register' ? 'register' : 'login');
    page.searchParams.set('return', window.location.href);
    window.location.assign(page.toString());
  }

  function logout() {
    currentUser = null;
    localStorage.removeItem(SESSION_KEY);
  }

  function restoreSession() {
    const storedUser = localStorage.getItem(SESSION_KEY);
    if (!storedUser) return;
    const users = loadUsers();
    if (!users[storedUser]) {
      localStorage.removeItem(SESSION_KEY);
      return;
    }
    currentUser = storedUser;
  }

  function openNotebookFromHashIfAvailable() {
    const fromHash = readNotebookNameFromHash();
    if (!fromHash) return false;
    if (currentUser) {
      const notebooks = getCurrentUserNotebooks();
      if (notebooks[fromHash]) {
        openNotebookByName(fromHash);
        return true;
      }
    }
    setCurrentNotebook(fromHash, { saved: false, syncHash: false });
    loadNotebookCells([{ type: 'code', source: '' }]);
    return true;
  }

  async function boot() {
    restoreSession();
    const loadedFromHash = openNotebookFromHashIfAvailable();

    let loadedFromUrl = false;
    if (allowUrlImport) {
      const url = new URL(window.location.href).searchParams.get('url');
      if (url) {
        try {
          await importNotebookFromUrl(url);
          loadedFromUrl = true;
        } catch (err) {
          alert(`Failed to import from URL: ${err.message}`);
        }
      }
    }

    if (!loadedFromHash && !loadedFromUrl) seedDefaultCells();
    if (!window.location.hash) updateNotebookHash();
    initWorker();
  }

  function onEditorInput(cell, event) {
    cell.source = event.currentTarget.value;
    event.currentTarget.style.height = 'auto';
    event.currentTarget.style.height = `${Math.max(60, event.currentTarget.scrollHeight)}px`;
    markNotebookDirty();
    cells = [...cells];
  }

  function onEditorKeydown(cell, event) {
    if (event.key === 'Tab') {
      event.preventDefault();
      const target = event.currentTarget;
      const s = target.selectionStart;
      const e = target.selectionEnd;
      target.setRangeText('    ', s, e, 'end');
      cell.source = target.value;
      markNotebookDirty();
      cells = [...cells];
    }
    if (event.key === 'Enter' && (event.shiftKey || event.metaKey || event.ctrlKey)) {
      event.preventDefault();
      runCell(cell.id);
    }
  }

  function setCellType(cellId, type) {
    const cell = findCell(cellId);
    if (!cell) return;
    cell.type = type === 'markdown' ? 'markdown' : 'code';
    markNotebookDirty();
    if (cell.type === 'markdown') executeMarkdown(cell);
    else {
      cell.execCount = null;
      cell.outputs = [];
      cells = [...cells];
    }
  }

  onMount(() => {
    boot();
  });

  onDestroy(() => {
    if (worker) worker.terminate();
    for (const cell of cells) {
      for (const out of cell.outputs || []) if (out.kind === 'iframe' && out.src?.startsWith('blob:')) URL.revokeObjectURL(out.src);
    }
  });
</script>

<header class="top-bar">
  <div class="logo">yipiii</div>
  <div class="top-actions">
    <span class={`kernel-status ${kernelStatus.status}`}>
      <span class="kernel-dot"></span>
      <span class="kernel-label">{kernelStatus.message}</span>
    </span>
    <span class="user-label">{currentUser || 'guest'}</span>
    <span class="notebook-chip">{notebookChip()}</span>

    {#if !currentUser}
      <button class="btn-primary" on:click={() => openAuth('login')}>Login</button>
      <button on:click={() => openAuth('register')}>Register</button>
    {:else}
      <button on:click={logout}>Logout</button>
    {/if}

    <button on:click={() => { saveName = currentNotebookName; saveError = ''; showSaveModal = true; }} disabled={!currentUser}>Save</button>
    <button on:click={() => { const names = Object.keys(getCurrentUserNotebooks()); if (names[0]) openNotebookByName(names[0]); }} disabled={!currentUser}>Open</button>
    <button on:click={() => fileInput?.click()}>Import</button>
    <button class="btn-primary" on:click={runAll} disabled={!workerReady}>▶▶ Run All</button>
    <button on:click={restartKernel} disabled={!workerReady}>↺ Restart</button>
    <button on:click={() => { appendCell('code', ''); markNotebookDirty(); }}>+ Cell</button>
    <input bind:this={fileInput} type="file" accept=".ipynb,application/json" hidden on:change={async (e) => {
      const file = e.currentTarget.files?.[0];
      if (!file) return;
      try { await importNotebookFromFile(file); } catch (err) { alert(`Failed to import notebook: ${err.message}`); }
      e.currentTarget.value = '';
    }} />
  </div>
</header>

<div class="workspace">
  <aside class={`notebook-sidebar ${!currentUser ? 'locked' : ''}`}>
    <div class="sidebar-header">
      <h3>Your notebooks</h3>
      <button on:click={() => { setCurrentNotebook('Untitled', { saved: false }); loadNotebookCells([{ type: 'code', source: '' }]); }} disabled={!currentUser}>+ New</button>
    </div>

    {#if !currentUser}
      <div class="sidebar-empty">
        🔒 Login to access your notebook library.<br />
        <button class="btn-primary" on:click={() => openAuth('login')}>Login</button>
      </div>
    {:else}
      <ul class="notebook-list">
        <li class={`notebook-list-item ${!currentNotebookSaved ? 'active' : ''}`} on:click={() => { setCurrentNotebook('Untitled', { saved: false }); loadNotebookCells([{ type: 'code', source: '' }]); }}>
          <span class="nb-name">Untitled (unsaved)</span>
          <span class="nb-date">local session</span>
        </li>
        {#each Object.entries(getCurrentUserNotebooks()).sort((a, b) => (b[1]?.savedAt || '').localeCompare(a[1]?.savedAt || '')) as [name, data]}
          <li class={`notebook-list-item ${currentNotebookSaved && name === currentNotebookName ? 'active' : ''}`} on:click={() => openNotebookByName(name)}>
            <span class="nb-name">{name}</span>
            <span class="nb-date">{data?.savedAt ? new Date(data.savedAt).toLocaleString() : 'unsaved'}</span>
          </li>
        {/each}
      </ul>
    {/if}
  </aside>

  <main id="notebook">
    {#each cells as cell (cell.id)}
      <div class={`cell ${cell.running ? 'running' : ''} ${cell.error ? 'error' : ''}`}>
        <div class="cell-gutter"><span class="exec-count">{cell.execCount === null ? (cell.type === 'markdown' ? '[md]:' : '') : `[${cell.execCount}]:`}</span></div>
        <div class="cell-body">
          <textarea
            class="cell-editor"
            value={cell.source}
            on:input={(e) => onEditorInput(cell, e)}
            on:keydown={(e) => onEditorKeydown(cell, e)}
          ></textarea>
          <div class="cell-toolbar">
            <select class="cell-type" value={cell.type} on:change={(e) => setCellType(cell.id, e.currentTarget.value)}>
              <option value="code">Code</option>
              <option value="markdown">Markdown</option>
            </select>
            <button class="run-btn" on:click={() => runCell(cell.id)}>▶ Run</button>
            <button on:click={() => moveCellUp(cell.id)}>↑</button>
            <button on:click={() => moveCellDown(cell.id)}>↓</button>
            <button on:click={() => deleteCell(cell.id)}>✕</button>
          </div>

          {#if cell.outputs.length > 0}
            <div class="output-area" style="position:relative">
              <button class="clear-output-btn" on:click={() => clearOutput(cell.id)}>clear</button>
              {#each cell.outputs as out, i}
                <div class="output-item">
                  {#if out.kind === 'text'}
                    <pre class={`output-text ${out.stream === 'stderr' ? 'stderr' : ''}`}>{out.text}</pre>
                  {:else if out.kind === 'displayText'}
                    <pre class="output-text">{out.text}</pre>
                  {:else if out.kind === 'error'}
                    <pre class="output-text error-traceback">{out.text}</pre>
                  {:else if out.kind === 'image'}
                    <img class="output-image" src={out.src} alt="output" />
                  {:else if out.kind === 'iframe'}
                    <iframe class="output-html-frame" sandbox="allow-scripts allow-popups" src={out.src} style={`height:${out.height || 120}px`}></iframe>
                  {/if}
                </div>
              {/each}
            </div>
          {/if}
        </div>
      </div>
    {/each}
  </main>
</div>

{#if !workerReady && kernelStatus.status === 'loading'}
  <div id="loading-overlay">
    <div class="spinner"></div>
    <div class="loading-text">{kernelStatus.message}</div>
  </div>
{/if}

{#if showSaveModal}
  <div class="auth-modal">
    <div class="auth-backdrop" on:click={() => { showSaveModal = false; saveError = ''; }}></div>
    <div class="auth-dialog" role="dialog" aria-modal="true">
      <h2>Save notebook</h2>
      <p class="auth-subtitle">Choose a name for this notebook.</p>
      <form class="auth-form" on:submit|preventDefault={saveNotebook}>
        <label>
          Notebook name
          <input bind:value={saveName} required />
        </label>
        {#if saveError}
          <div class="auth-error">{saveError}</div>
        {/if}
        <div class="auth-actions">
          <button type="button" on:click={() => { showSaveModal = false; saveError = ''; }}>Cancel</button>
          <button id="save-submit-btn" type="submit">Save</button>
        </div>
      </form>
    </div>
  </div>
{/if}
