<script>
  import { onMount } from 'svelte';

  const USERS_KEY = 'yipiii.users.v1';
  const SESSION_KEY = 'yipiii.session.v1';

  let mode = 'login';
  let username = '';
  let password = '';
  let error = '';
  let ssoLog = 'Idle.';

  function loadUsers() {
    try { return JSON.parse(localStorage.getItem(USERS_KEY) || '{}'); } catch { return {}; }
  }

  function saveUsers(users) {
    localStorage.setItem(USERS_KEY, JSON.stringify(users));
  }

  function getReturnCandidateFromHash() {
    const hash = window.location.hash.replace(/^#/, '');
    if (!hash) return null;
    const params = new URLSearchParams(hash);
    return params.get('return') || hash;
  }

  function getSafeReturnTarget() {
    const searchParams = new URLSearchParams(window.location.search);
    const candidates = [searchParams.get('return'), getReturnCandidateFromHash()];
    for (const candidate of candidates) {
      if (!candidate) continue;
      try {
        const parsed = new URL(candidate, window.location.origin);
        if (parsed.origin === window.location.origin) return parsed.toString();
      } catch {}
    }
    return new URL('/', window.location.origin).toString();
  }

  function redirectAfterAuth() {
    window.location.assign(getSafeReturnTarget());
  }

  function beginWipSso() {
    const callbackUrl = new URL('/auth/', window.location.origin);
    callbackUrl.searchParams.set('sso', 'callback');
    callbackUrl.searchParams.set('mode', 'login');
    callbackUrl.searchParams.set('token', 'wip-demo-token');
    callbackUrl.searchParams.set('return', new URLSearchParams(window.location.search).get('return') || '/');

    ssoLog = [
      'WIP SSO bootstrap complete.',
      `Callback target: ${callbackUrl.toString()}`,
      'Simulating IdP redirect now...'
    ].join('\n');

    setTimeout(() => window.location.assign(callbackUrl.toString()), 500);
  }

  function maybeHandleSsoCallback() {
    const params = new URLSearchParams(window.location.search);
    if (params.get('sso') !== 'callback') return false;

    const token = params.get('token');

    if (!token) {
      error = 'SSO callback validation failed.';
      ssoLog = 'SSO callback rejected: missing token.';
      return true;
    }

    const users = loadUsers();
    if (!users['sso-demo']) {
      users['sso-demo'] = { password: '__sso__', notebooks: {} };
      saveUsers(users);
    }

    localStorage.setItem(SESSION_KEY, 'sso-demo');
    redirectAfterAuth();
    return true;
  }

  function submitAuth(e) {
    e.preventDefault();
    error = '';

    const u = username.trim();
    if (!u || !password) {
      error = 'Enter username and password.';
      return;
    }

    const users = loadUsers();

    if (mode === 'register') {
      if (users[u]) {
        error = 'User already exists.';
        return;
      }
      users[u] = { password, notebooks: {} };
      saveUsers(users);
      localStorage.setItem(SESSION_KEY, u);
      redirectAfterAuth();
      return;
    }

    if (!users[u] || users[u].password !== password) {
      error = 'Invalid credentials.';
      return;
    }

    localStorage.setItem(SESSION_KEY, u);
    redirectAfterAuth();
  }

  onMount(() => {
    mode = new URLSearchParams(window.location.search).get('mode') === 'register' ? 'register' : 'login';
    maybeHandleSsoCallback();
  });
</script>

<svelte:head>
  <title>yipiii auth</title>
</svelte:head>

<div class="auth-page">
  <main class="auth-page-wrap">
    <section class="auth-page-card">
      <div class="logo">yipiii</div>
      <h1>{mode === 'register' ? 'Register' : 'Login'}</h1>
      <p class="auth-subtitle">{mode === 'register' ? 'Create account to keep notebooks per user.' : 'Sign in to access your notebooks.'}</p>

      <div class="auth-mode-row">
        <button class={`auth-tab ${mode === 'login' ? 'active' : ''}`} type="button" on:click={() => mode = 'login'}>Login</button>
        <button class={`auth-tab ${mode === 'register' ? 'active' : ''}`} type="button" on:click={() => mode = 'register'}>Register</button>
      </div>

      <form class="auth-form" on:submit={submitAuth}>
        <label>Username <input bind:value={username} autocomplete="username" required /></label>
        <label>Password <input bind:value={password} type="password" autocomplete="current-password" required /></label>
        {#if error}<div class="auth-error">{error}</div>{/if}
        <div class="auth-actions">
          <button type="button" on:click={() => window.location.assign(getSafeReturnTarget())}>Back</button>
          <button class="btn-primary" id="auth-page-submit" type="submit">{mode === 'register' ? 'Create account' : 'Login'}</button>
        </div>
      </form>
    </section>

    <aside class="auth-page-card auth-wip-card">
      <h2>SSO (WIP)</h2>
      <p class="auth-subtitle">Prepared auth plumbing for same-origin callback handling.</p>
      <button class="btn-primary" id="sso-btn" type="button" on:click={beginWipSso}>Continue with Entra ID (WIP)</button>
      <pre class="sso-log">{ssoLog}</pre>
    </aside>
  </main>
</div>
